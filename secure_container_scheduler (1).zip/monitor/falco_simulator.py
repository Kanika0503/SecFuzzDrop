def simulate_falco_alerts():
    return "ALERT: Unexpected file access by container c2"
