def simulate_cadvisor_metrics():
    return {
        "container_0": {"cpu": "45%", "mem": "512MB"},
        "container_1": {"cpu": "55%", "mem": "600MB"},
    }
